import rateLimit from 'express-rate-limit';

/**
 * Helper to bypass rate limiting in test environment or when explicitly disabled
 */
const shouldSkip = () => {
  return process.env.NODE_ENV === 'test' || process.env.DISABLE_RATE_LIMIT === 'true';
};

const safeKeyGenerator = (req) => {
  return (
    req.ip ||
    req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
    req.socket?.remoteAddress ||
    '127.0.0.1'
  );
};

/**
 * Standard / General API Limiter (applied to all /api routes)
 * 300 requests per 15 minutes per IP
 */
export const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: safeKeyGenerator,
  validate: { ip: false, default: false },
  skip: shouldSkip,
  message: {
    success: false,
    message: 'Too many requests from this IP address, please try again in 15 minutes.',
  },
});

/**
 * Strict Auth Limiter (applied to /api/auth/login, /api/auth/signup)
 * Protects against brute-force attacks and credential stuffing
 * 20 attempts per 15 minutes per IP
 */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: safeKeyGenerator,
  validate: { ip: false, default: false },
  skip: shouldSkip,
  message: {
    success: false,
    message: 'Too many authentication attempts from this IP. Please try again after 15 minutes.',
  },
});

/**
 * Strict Action Limiter (applied to payments and document uploads)
 * 60 actions per 15 minutes per IP
 */
export const strictActionLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: safeKeyGenerator,
  validate: { ip: false, default: false },
  skip: shouldSkip,
  message: {
    success: false,
    message: 'Action rate limit exceeded. Please wait a moment before trying again.',
  },
});
