import * as landlordDocService from './documents.service.js';

export async function getDocuments(req, res) {
  try {
    const landlordId = req.user._id || req.user.id;
    const result = await landlordDocService.getLandlordDocuments(landlordId, req.query);
    return res.status(200).json({ success: true, data: result.documents, documents: result.documents, ...result });
  } catch (err) {
    const statusCode = err.statusCode || 500;
    return res.status(statusCode).json({ success: false, message: err.message });
  }
}

export async function verifyDocument(req, res) {
  try {
    const landlordId = req.user._id || req.user.id;
    const ipAddress = req.ip || req.connection?.remoteAddress || '';
    const result = await landlordDocService.verifyDocument(landlordId, req.params.id, req.body, ipAddress);
    return res.status(200).json(result);
  } catch (err) {
    const statusCode = err.statusCode || 400;
    return res.status(statusCode).json({ success: false, message: err.message });
  }
}

export async function deleteDocument(req, res) {
  try {
    const landlordId = req.user._id || req.user.id;
    const ipAddress = req.ip || req.connection?.remoteAddress || '';
    const result = await landlordDocService.deleteDocument(landlordId, req.params.id, ipAddress);
    return res.status(200).json(result);
  } catch (err) {
    const statusCode = err.statusCode || 400;
    return res.status(statusCode).json({ success: false, message: err.message });
  }
}

export async function getDocumentFile(req, res) {
  try {
    const landlordId = req.user._id || req.user.id;
    const { stream, name, mimeType } = await landlordDocService.getDocumentStream(landlordId, req.params.id);
    res.setHeader('Content-Type', mimeType || 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(name)}"`);
    const { Readable } = await import('node:stream');
    const nodeStream = Readable.fromWeb(stream);
    return nodeStream.pipe(res);
  } catch (err) {
    const statusCode = err.statusCode || 500;
    return res.status(statusCode).json({ success: false, message: err.message });
  }
}

